// input{} loads workspace txt file as value and filename as key
// output[{}] represents row objects of output sheet

const data = JSON.parse(api.read('result.txt'));

output.header = ["title", "url"];

for (const item of data) {
  output.push([item.title, item.url]);
}
